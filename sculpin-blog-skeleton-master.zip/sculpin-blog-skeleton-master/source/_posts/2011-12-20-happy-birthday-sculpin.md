---
title: Happy Birthday Sculpin!
tags:
    - sculpin
    - markdown
categories:
    - personal

---
The first commit to the Sculpin repository was made on December 20th, 2011.
What a trip since then!

Sculpin has always been a big fan of [Markdown][1]. So this post was
written in Markdown. :)

[1]: http://daringfireball.net/projects/markdown/
