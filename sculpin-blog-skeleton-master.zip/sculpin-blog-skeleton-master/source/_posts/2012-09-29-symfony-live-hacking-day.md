---
title: Symfony Live Hacking Day!
tags: [sensio, symfony, symfony live]
categories: [personal]

---
Fun times at the Symfony Live San Francisco 2012 Hacking Day! Code
was hacked and pizza was had. Some pics of the conference are
available on the [Sensio Labs Facebook page][1].

[1]: https://www.facebook.com/media/set/?set=a.450514941665306.112810.129739647076172
